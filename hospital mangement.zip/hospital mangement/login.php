<?php

if(isset($_COOKIE['admin']))
{
	header("location: AdminDashboard.php");
}else if(isset($_COOKIE['doctor']))
{
	header("location: DoctorDashboard.php");
}

?>


<!DOCTYPE HTML>
<html>
<head>

	<title>Login as Admin or Doctor</title>
	<link rel="stylesheet" type="text/css" href="style2.css">  
</head>
<body>
	
 <div class="login-box">
    <img src="avatar.png" class="avatar">
        <h1>Login Here</h1>
           

<form method="POST" action="validate_login.php">
<p>Username</p>
<input placeholder="USERNAME" type="text" name="username" align="center"/></br>
<p>Password</p>
<input placeholder="PASSWORD" type="password" name="password"/>
<input type="checkbox" name="remember" value="1">Remember Me</br>
<input type="submit" value="Login" name="login"/></br>

</form>
<?php

if(  isset($_REQUEST["pwd_error"]) ){
	echo $_REQUEST["pwd_error"];
	
}



?>


</body>
	
</html> 

