
<?php

	session_start();
	echo $_SESSION['username'];
	echo "<a href='logout.php'>Logout</a>";
	
/* 	
	if(!isset($_COOKIE['doctor'])){
		echo '<a href="login.php">Login</a>';
		
	}else
	{
		echo '<a href="logout.php">Logout</a>';
		
	} */


?> 
